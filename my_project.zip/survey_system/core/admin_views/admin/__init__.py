from .results import admin_results_view
from .rating import admin_rating_view

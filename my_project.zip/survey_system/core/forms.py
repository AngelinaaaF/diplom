from django import forms
from core.models import Survey, Faculty, Department, DepartmentStaff, Subject, Group, QuestionBank

class CombinedSurveyForm(forms.ModelForm):
    faculty = forms.ModelMultipleChoiceField(queryset=Faculty.objects.all(), required=False)
    department = forms.ModelMultipleChoiceField(queryset=Department.objects.all(), required=False)
    teacher = forms.ModelMultipleChoiceField(queryset=DepartmentStaff.objects.all(), required=False)
    subject = forms.ModelMultipleChoiceField(queryset=Subject.objects.all(), required=False)
    group = forms.ModelMultipleChoiceField(queryset=Group.objects.all(), required=False)

    questions = forms.ModelMultipleChoiceField(
        queryset=QuestionBank.objects.all(),
        widget=forms.CheckboxSelectMultiple,
        label="Вопросы"
    )

    class Meta:
        model = Survey
        fields = ['name', 'year', 'start_date']
        widgets = {
            'start_date': forms.DateInput(attrs={'type': 'date'}),
        }

class NewQuestionForm(forms.ModelForm):
    class Meta:
        model = QuestionBank
        fields = ['text', 'characteristic']
        widgets = {
            'text': forms.Textarea(attrs={'rows': 2, 'required': False}),
            'characteristic': forms.Select(attrs={'required': False}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['text'].required = False
        self.fields['characteristic'].required = False

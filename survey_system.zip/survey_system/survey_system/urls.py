
from core.admin_views import survey_wizard
from django.contrib import admin
from django.urls import path
from django.contrib.auth import views as auth_views
from core.views import student_home, start_survey, redirect_after_login,survey_results,teacher_home

from core.admin_views.admin.results import admin_results_view
from core.admin_views.admin.rating import admin_rating_view
from django.http import HttpResponse

from core.admin_views.survey_create import create_survey

urlpatterns = [
    path('teacher/admin/survey/create/', create_survey, name='create_survey'),
    path('teacher/admin/form/create/', survey_wizard.choose_or_create, name='choose_or_create'),
    path('teacher/admin/form/create/new/', survey_wizard.create_new_survey, name='create_new_survey'),
    path('teacher/admin/form/<int:survey_id>/edit/name/', survey_wizard.edit_survey_name, name='edit_survey_name'),
    path('teacher/admin/form/<int:survey_id>/edit/questions/', survey_wizard.edit_survey_questions, name='edit_survey_questions'),
    path('teacher/admin/form/<int:survey_id>/edit/settings/', survey_wizard.edit_survey_settings, name='edit_survey_settings'),
    path('admin/form/create/from/<int:source_id>/', survey_wizard.clone_survey, name='clone_survey'),


    path('admin/', admin.site.urls),
    path('', auth_views.LoginView.as_view(), name='login'),
    path('logout/', auth_views.LogoutView.as_view(next_page='/'), name='logout'),
    path('home/', redirect_after_login, name='redirect_after_login'),
    path('student/home/', student_home, name='student_home'),
    path('survey/<int:survey_id>/start/', start_survey, name='start_survey'),
    path('teacher/home/', teacher_home, name='teacher_home'),
    path('survey/<int:survey_id>/results/', survey_results, name='survey_results'),
    path('teacher/admin/results/', admin_results_view, name='admin_results'),
    path('teacher/admin/rating/', admin_rating_view, name='admin_rating'),

]
